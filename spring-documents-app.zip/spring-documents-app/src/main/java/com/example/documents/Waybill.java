package com.example.documents;

public class Waybill extends Document {
    private String orderId;
    private String paymentId;
    private String shippingMethod;

    public Waybill(Order order, Payment payment) {
        this.orderId = order.getId();
        this.paymentId = payment.getId();
        setAmount(order.getAmount());
        setCustomerName(order.getCustomerName());
        setNumber("WAY-" + System.currentTimeMillis());
        this.shippingMethod = "Standard";
    }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getPaymentId() { return paymentId; }
    public void setPaymentId(String paymentId) { this.paymentId = paymentId; }

    public String getShippingMethod() { return shippingMethod; }
    public void setShippingMethod(String shippingMethod) {
        this.shippingMethod = shippingMethod;
    }
}