package com.example.documents;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

public abstract class Document {
    private String id;
    private String number;
    private LocalDateTime date;
    private BigDecimal amount;
    private String customerName;

    public Document() {
        this.id = UUID.randomUUID().toString();
        this.date = LocalDateTime.now();
    }

    public String getId() { return id; }

    public String getNumber() { return number; }
    public void setNumber(String number) { this.number = number; }

    public LocalDateTime getDate() { return date; }
    public void setDate(LocalDateTime date) { this.date = date; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
}