package com.example.documents;

import java.time.LocalDateTime;

public class Invoice extends Document {
    private String orderId;
    private LocalDateTime dueDate;
    private boolean isPaid;

    public Invoice(Order order) {
        this.orderId = order.getId();
        setAmount(order.getAmount());
        setCustomerName(order.getCustomerName());
        setNumber("INV-" + System.currentTimeMillis());
        this.dueDate = order.getDate().plusDays(30);
        this.isPaid = false;
    }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public LocalDateTime getDueDate() { return dueDate; }
    public void setDueDate(LocalDateTime dueDate) { this.dueDate = dueDate; }

    public boolean isPaid() { return isPaid; }
    public void setPaid(boolean paid) { isPaid = paid; }
}