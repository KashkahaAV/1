package com.example.documents;

public class Payment extends Document {
    private String invoiceId;
    private String paymentMethod;

    public Payment(Invoice invoice, String paymentMethod) {
        this.invoiceId = invoice.getId();
        setAmount(invoice.getAmount());
        setCustomerName(invoice.getCustomerName());
        setNumber("PAY-" + System.currentTimeMillis());
        this.paymentMethod = paymentMethod;
    }

    public String getInvoiceId() { return invoiceId; }
    public void setInvoiceId(String invoiceId) { this.invoiceId = invoiceId; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
}