package com.example.documents;

import java.math.BigDecimal;

public class Order extends Document {
    private String productName;
    private int quantity;
    private String deliveryAddress;

    public Order(String productName, int quantity, BigDecimal amount,
                 String customerName, String deliveryAddress) {
        setProductName(productName);
        setQuantity(quantity);
        setAmount(amount);
        setCustomerName(customerName);
        setDeliveryAddress(deliveryAddress);
        setNumber("ORD-" + System.currentTimeMillis());
    }

    public String getProductName() { return productName; }
    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getDeliveryAddress() { return deliveryAddress; }
    public void setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }
}