package com.example;

import com.example.config.AppConfig;
import com.example.service.DocumentService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.util.Scanner;

public class Application {
    public static void main(String[] args) {
        // Создаем Spring контейнер
        ApplicationContext context =
                new AnnotationConfigApplicationContext(AppConfig.class);

        // Получаем bean DocumentService из контейнера
        DocumentService documentService =
                context.getBean(DocumentService.class);

        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Система управления документами ===");

        while (true) {
            System.out.println("\nМеню:");
            System.out.println("1. Создать новую цепочку документов");
            System.out.println("2. Показать цепочку документов по номеру");
            System.out.println("3. Показать все цепочки документов");
            System.out.println("4. Выход");
            System.out.print("Выберите действие: ");

            try {
                int choice = scanner.nextInt();
                scanner.nextLine(); // очистка буфера

                switch (choice) {
                    case 1:
                        System.out.print("\nНаименование товара: ");
                        String product = scanner.nextLine();
                        System.out.print("Количество: ");
                        int quantity = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Имя покупателя: ");
                        String customer = scanner.nextLine();
                        System.out.print("Адрес доставки: ");
                        String address = scanner.nextLine();
                        System.out.print("Способ оплаты (карта/наличные): ");
                        String paymentMethod = scanner.nextLine();

                        // Создание цепочки документов
                        var order = documentService.createOrder(
                                product, quantity, customer, address);
                        var invoice = documentService.createInvoice(order);
                        var payment = documentService.createPayment(
                                invoice, paymentMethod);
                        var waybill = documentService.createWaybill(order, payment);

                        System.out.println("\n✓ Цепочка документов создана!");
                        System.out.println("Номер цепочки: " +
                                (documentService.getOrders().size() - 1));
                        break;

                    case 2:
                        System.out.print("Введите номер цепочки (с 0): ");
                        int index = scanner.nextInt();
                        documentService.printDocumentChain(index);
                        break;

                    case 3:
                        System.out.println("\n=== Все цепочки документов ===");
                        int chainCount = documentService.getOrders().size();
                        for (int i = 0; i < chainCount; i++) {
                            documentService.printDocumentChain(i);
                        }
                        break;

                    case 4:
                        System.out.println("Выход из программы...");
                        scanner.close();
                        return;

                    default:
                        System.out.println("Неверный выбор!");
                }
            } catch (Exception e) {
                System.out.println("Ошибка: " + e.getMessage());
                scanner.nextLine(); // очистка буфера при ошибке
            }
        }
    }
}