package com.example.service;

import com.example.documents.*;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.*;

@Service
public class DocumentService {
    private List<Order> orders = new ArrayList<>();
    private List<Invoice> invoices = new ArrayList<>();
    private List<Payment> payments = new ArrayList<>();
    private List<Waybill> waybills = new ArrayList<>();

    public Order createOrder(String productName, int quantity,
                             String customerName, String deliveryAddress) {
        BigDecimal amount = BigDecimal.valueOf(quantity * 100);
        Order order = new Order(productName, quantity, amount,
                customerName, deliveryAddress);
        orders.add(order);
        return order;
    }

    public Invoice createInvoice(Order order) {
        Invoice invoice = new Invoice(order);
        invoices.add(invoice);
        return invoice;
    }

    public Payment createPayment(Invoice invoice, String paymentMethod) {
        Payment payment = new Payment(invoice, paymentMethod);
        payments.add(payment);
        invoice.setPaid(true);
        return payment;
    }

    public Waybill createWaybill(Order order, Payment payment) {
        Waybill waybill = new Waybill(order, payment);
        waybills.add(waybill);
        return waybill;
    }

    public void printDocumentChain(int index) {
        if (index < orders.size()) {
            Order order = orders.get(index);
            System.out.println("\n=== Цепочка документов #" + index + " ===");
            System.out.println("1. Заказ: " + order.getNumber() +
                    " | Товар: " + order.getProductName() +
                    " | Сумма: " + order.getAmount() +
                    " | Клиент: " + order.getCustomerName());

            if (index < invoices.size()) {
                Invoice invoice = invoices.get(index);
                System.out.println("2. Счет: " + invoice.getNumber() +
                        " | Оплачен: " + (invoice.isPaid() ? "Да" : "Нет") +
                        " | Срок: " + invoice.getDueDate().toLocalDate());

                if (index < payments.size()) {
                    Payment payment = payments.get(index);
                    System.out.println("3. Оплата: " + payment.getNumber() +
                            " | Способ: " + payment.getPaymentMethod());

                    if (index < waybills.size()) {
                        Waybill waybill = waybills.get(index);
                        System.out.println("4. Накладная: " + waybill.getNumber() +
                                " | Доставка: " + waybill.getShippingMethod());
                    }
                }
            }
        } else {
            System.out.println("Цепочка документов #" + index + " не найдена!");
        }
    }

    public List<Order> getOrders() { return orders; }
    public List<Invoice> getInvoices() { return invoices; }
    public List<Payment> getPayments() { return payments; }
    public List<Waybill> getWaybills() { return waybills; }
}